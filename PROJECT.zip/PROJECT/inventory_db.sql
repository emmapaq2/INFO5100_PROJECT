CREATE DATABASE inventory_db;

USE inventory_db;

CREATE TABLE users (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `location` varchar(45) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(45) NOT NULL,
  `usertype` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
);

CREATE TABLE usertypes (
`id` int not null auto_increment,
`utype` varchar(30) NOT NULL,
primary key(`id`));

CREATE TABLE currentstock (
`productcode` varchar(45) NOT NULL,
`quantity` int NOT NULL,
PRIMARY KEY (`productcode`)
);

CREATE TABLE customers (
`cid` int NOT NULL auto_increment,
`customercode` varchar(45) NOT NULL,
`fullname` varchar(45) NOT NULL,
`location` varchar(45) NOT NULL,
`phone` varchar (45) NOT NULL,
PRIMARY KEY (cid));

CREATE TABLE purchaseinfo (
`purchaseID` int not nULL AUTO_INCREMENT,
`suppliercode` varchar(45) NOT NULL,
`productcode` varchar(45) NoT NULL,
`date` varchar(45) NOT NULL,
`quantity` int NOT NULL,
`totalcost` double NOT NULL,
PRIMARY KEY (purchaseID)
);

CREATE TABLE `suppliers` (
`sid` int not nULL AUTO_INCREMENT,
`suppliercode` varchar(45) NoT NULL,
`fullname` varchar(45) NOT NULL,
`location` varchar(45) NOT NULL,
`mobile` varchar(45) not null,
PRIMARY KEY (sid)
);

CREATE TABLE products (
  `pid` int NOT NULL AUTO_INCREMENT,
  `productcode` varchar(45) NOT NULL,
  `productname` varchar(45) NOT NULL,
  `costprice` double NOT NULL,
  `sellprice` double NOT NULL,
  `brand` varchar(45) NOT NULL,
  PRIMARY KEY (`pid`),
  UNIQUE KEY `productcode_UNTQUE` (`productcode`)
);

CREATE TABLE salesinfo (
  `salesid` int NOT NULL AUTO_INCREMENT,
  `date` varchar(45) NOT NULL,
  `productcode` varchar(45) NOT NULL,
  `customercode` varchar(45) NOT NULL,
  `quantity` int NOT NULL,
  `revenue` double NOT NULL,
  `soldby` varchar(45) NOT NULL,
  PRIMARY KEY (`salesid`)
);
